Tyche v1.1.2
- https://github.com/ColorlibHQ/tyche/milestone/1?closed=1

Tyche v1.1.1
- Fixed security issue

Tyche v1.1.0
- Fixed Tyche Icons ( https://github.com/puikinsh/tyche/issues/38 )
- Added settings for setting number of columns and products per page ( https://github.com/puikinsh/tyche/issues/39 )
- Added control to disable product zoom on hover ( https://github.com/puikinsh/tyche/issues/40 )
- Added real time update of minicart ( https://github.com/puikinsh/tyche/issues/41 )
- Added option to translate slider text ( https://github.com/puikinsh/tyche/issues/42 )
- Updated WooCommerce files ( https://github.com/puikinsh/tyche/issues/47 )
- Fixed : Hide out of stock products ( https://github.com/puikinsh/tyche/issues/46 )

Tyche v1.0.13
- https://themes.trac.wordpress.org/ticket/47201#comment:4

Tyche v1.0.12
- Added documentation section in customizer
- Fixed a few escapes
- Fixed deprecated Kirki warning (fields should not be added through the customize_register hook)
- Removed epsilon framework as a submodule dependency, added it as a normal library (stripped of what is not used)

Tyche v1.0.11
- Adsense was not initiated

Tyche v1.0.10
- Small issues

Tyche v1.0.8
- Update theme screenshot
- Frontpage now displays the static page if no sidebars are used

Tyche v1.0.7
- Updated welcome screen
- Added a notice in the frontend if user does not have widgets in the content area
- Removed documentation section
- Bug fixes

Tyche v1.0.6
- Bug Fixes

Tyche v1.0.5
- Bug Fixes
- https://themes.trac.wordpress.org/ticket/43404#comment:6

Tyche v1.0.4
- Bug fixes
- https://themes.trac.wordpress.org/ticket/43404#comment:3

Tyche v1.0.2
- Bug fixes ( https://github.com/puikinsh/tyche/pull/7 )
- Update theme screenshot

Tyche v1.0.2
- Bug fixes for mobile environments

Tyche v1.0.1
- Bug fixing found when creating the demo content

Tyche v1.0.0 
- Release to w.org for theme review

